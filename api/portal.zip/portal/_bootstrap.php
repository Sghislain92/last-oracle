<?php
declare(strict_types=1);
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/helpers.php';

const PORTAL_COOKIE = 'oracle_portal_session';
const PORTAL_TTL = 60 * 60 * 24 * 30;

function portalJson(int $status, array $data): void { sendJson($status, $data); }
function portalBody(): array { return readJsonBody(); }
function portalCookieOptions(): array { return ['expires' => time() + PORTAL_TTL, 'path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']; }
function portalToken(array $partner): string { return createSessionToken(['portal' => true, 'partnerId' => $partner['id'], 'email' => $partner['email']]); }
function portalUser(): ?array {
    $token = $_COOKIE[PORTAL_COOKIE] ?? '';
    if (!$token) return null;
    $payload = verifySessionToken($token);
    if (!$payload || empty($payload['portal']) || empty($payload['partnerId'])) return null;
    $stmt = getPdo()->prepare('SELECT id, email, company_name, contact_name, active, created_at, last_login_at FROM api_partners WHERE id = ?');
    $stmt->execute([$payload['partnerId']]);
    $partner = $stmt->fetch();
    return ($partner && (int)$partner['active']) ? $partner : null;
}
function requirePortalUser(): array { $user = portalUser(); if (!$user) portalJson(401, ['error' => 'Connexion au portail API requise.']); return $user; }
function portalAudit(string $partnerId, string $type, string $message, ?array $metadata = null): void {
    $pdo = getPdo();
    $pdo->prepare('INSERT INTO api_portal_events (id, partner_id, type, status, message, metadata, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')->execute([uuidV4(), $partnerId, $type, 'info', $message, $metadata ? json_encode($metadata, JSON_UNESCAPED_UNICODE) : null, getClientIp(), getClientUserAgent()]);
}
handleCors();
