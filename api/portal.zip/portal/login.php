<?php
require_once __DIR__ . '/_bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') portalJson(405, ['error' => 'Méthode non autorisée.']);
$body = portalBody();
$email = strtolower(trim((string)($body['email'] ?? ''))); $password = (string)($body['password'] ?? '');
$pdo = getPdo(); $stmt = $pdo->prepare('SELECT * FROM api_partners WHERE email = ?'); $stmt->execute([$email]); $partner = $stmt->fetch();
if (!$partner || !password_verify($password, $partner['password_hash'])) {
    if ($partner) { $pdo->prepare('INSERT INTO api_portal_events (id, partner_id, type, status, message, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute([uuidV4(), $partner['id'], 'auth.login_failed', 'error', 'Identifiants invalides.', getClientIp(), getClientUserAgent()]); }
    portalJson(401, ['error' => 'E-mail ou mot de passe incorrect.']);
}
if (!(int)$partner['active']) portalJson(403, ['error' => 'Ce compte partenaire est désactivé.']);
$pdo->prepare('UPDATE api_partners SET last_login_at = NOW(3), login_count = login_count + 1 WHERE id = ?')->execute([$partner['id']]);
setcookie(PORTAL_COOKIE, portalToken($partner), portalCookieOptions());
portalAudit($partner['id'], 'auth.login', 'Connexion au portail API.');
portalJson(200, ['ok' => true, 'user' => ['id' => $partner['id'], 'email' => $partner['email'], 'companyName' => $partner['company_name'], 'contactName' => $partner['contact_name']]]);
