<?php
require_once __DIR__ . '/_bootstrap.php';
$user = requirePortalUser();
$pdo = getPdo();

$eventsStmt = $pdo->prepare('SELECT id, type, status, message, metadata, ip_address, user_agent, created_at FROM api_portal_events WHERE partner_id = ? ORDER BY created_at DESC LIMIT 200');
$eventsStmt->execute([$user['id']]);
$events = $eventsStmt->fetchAll();

// Les appels réalisés avec les clés du partenaire viennent de l'audit API.
$auditStmt = $pdo->prepare(
    "SELECT a.id, a.query_type, a.query_value, a.found, a.ip_address, a.created_at, k.label
     FROM api_key_audit a INNER JOIN api_keys k ON k.id = a.api_key_id
     WHERE k.created_by = ? ORDER BY a.created_at DESC LIMIT 200"
);
$auditStmt->execute([$user['id']]);
foreach ($auditStmt->fetchAll() as $row) {
    $events[] = [
        'id' => 'audit-' . $row['id'],
        'type' => 'api.lookup',
        'status' => (int)$row['found'] ? 'found' : 'not_found',
        'message' => 'Recherche ' . strtoupper((string)$row['query_type']) . ' · ' . $row['query_value'] . ' · ' . $row['label'],
        'metadata' => null,
        'ip_address' => $row['ip_address'],
        'user_agent' => null,
        'created_at' => $row['created_at'],
    ];
}
usort($events, static fn(array $a, array $b): int => strcmp((string)$b['created_at'], (string)$a['created_at']));
portalJson(200, ['ok' => true, 'events' => array_slice($events, 0, 300)]);
