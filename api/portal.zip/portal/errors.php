<?php
require_once __DIR__ . '/_bootstrap.php';
$user = requirePortalUser();
$stmt = getPdo()->prepare("SELECT id, type, status, message, ip_address, user_agent, created_at FROM api_portal_events WHERE partner_id = ? AND status = 'error' ORDER BY created_at DESC LIMIT 100");
$stmt->execute([$user['id']]);
portalJson(200, ['ok' => true, 'errors' => $stmt->fetchAll()]);
